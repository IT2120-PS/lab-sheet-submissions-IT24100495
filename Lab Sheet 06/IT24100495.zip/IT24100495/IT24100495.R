setwd("C:\\Users\\miyur\\OneDrive\\Desktop\\IT24100495")
getwd()


  # Exercise 1 
#Q1
n <- 50       
p <- 0.85      
cat("Binomial distribution is: (n =", n, ", p =", p, ")\n")


n <- 50
p <- 0.85
prob_atleast47 <- 1 - pbinom(46, size=n, prob=p)
cat("Probability of atleast 47 students pass =", prob_atleast47, "\n")

#Q2
  
cat("X = number of calls per hour\n")

lambda <- 12
cat(" distribution of X: Poisson(lambda =", lambda, ")\n")

prob_exact15 <- dpois(15, lambda=lambda)
cat("P(X = 15) =", prob_exact15, "\n")